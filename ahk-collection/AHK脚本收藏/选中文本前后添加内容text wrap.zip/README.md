# text wrap

wrap selected text in <symbols>

 

**hotkey**:

- select a word or sentence
- press alt + 2
- e.g. selected text will change to "selected text"

 

**hotstring**:

- copy a word or sentence to the clipboard first
- place the cursor where you want the text to be pasted
- type w then 2
- then spacebar or enter to send the hotstring

 

| hotkey          | hotstring | wrapped         |                                            |
| --------------- | --------- | --------------- | ------------------------------------------ |
| alt + 2         | w2        | "text"          |                                            |
| alt + '         | w'        | 'text'          | monospace text (**MD**)                    |
| alt + `         | w`        | `text`          | literal text / in-line code block (**MD**) |
| alt + 9         | w9        | (text)          |                                            |
| alt + [         | w[        | [text]          |                                            |
| alt + ]         | w]        | {text}          |                                            |
| alt + ,         | w,        | <text>          |                                            |
| alt + 5         | w5        | %text%          |                                            |
| alt + .         | w.        | >>text<<        |                                            |
| alt + 8         | w8        | *text*          | italic text (**MD**) / bold text (**YT**)  |
| alt + shift + 8 | w*        | **text**        | bold text (**MD**)                         |
| alt + shift + # | w~        | ~~text~~        | strike through text (**MD**)               |
| alt + -         | w-        | -text-          | strike through text (**YT**)               |
| alt + shift + - | w_        | _text_          | italic text (**YT**)                       |
| alt + k         | wkbd      | <kbd>text</kbd> | markdown key syntax                        |
|                 |           |                 |                                            |
| alt + del       | wdel      | text            | deletes up to 2 characters on either side  |

**MD** - markdown, **YT** - YouTube

 

- if no text is selected when using the hotkey then the symbols will be pasted and the cursor will be moved between them
- alt + del deletes up to two wrap characters if they are on either side: %text% to text